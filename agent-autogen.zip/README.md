# AI Assistant — Complete Setup Guide
### Built with Microsoft AutoGen + Claude on AWS Bedrock AgentCore

---

## What You Will Build

```
╔═══════════════════════════════════════╗
║          AI Assistant                 ║
╠═══════════════════════════════════════╣
║  ✅  Says hello and greets you        ║
║  ✅  Answers any question             ║
║  ✅  Searches the internet live       ║
║  ✅  Uses Claude on AWS Bedrock       ║
║  ✅  Runs on AWS Bedrock AgentCore    ║
╚═══════════════════════════════════════╝
```

### Your Project Files

```
ai_assistant/
├── agent.py          ← The agent (AutoGen + Claude + internet search)
├── requirements.txt  ← Python packages
├── invoke.py         ← Chat with your deployed agent
└── README.md         ← This guide
```

### How It All Works Together

```
  YOU
   │
   │  python invoke.py
   ▼
 invoke.py  ──── sends {"prompt": "your question"} via boto3 ────►
                                                                   │
                                              AWS Bedrock AgentCore Runtime
                                                                   │
                                                             agent.py runs
                                                                   │
                                              ┌────────────────────┴──────────┐
                                              │  Microsoft AutoGen            │
                                              │  AssistantAgent               │
                                              │       │                       │
                                              │  Claude 3.5 Sonnet            │
                                              │  (via AWS Bedrock)            │
                                              │       │                       │
                                              │  Decides: search needed?      │
                                              │       │         │             │
                                              │       │    web_search()       │
                                              │       │    DuckDuckGo         │
                                              │       │    ← results          │
                                              │       │         │             │
                                              │  Final answer                 │
                                              └───────────────────────────────┘
                                                                   │
   ◄─────────────── returns {"response": "agent's answer"} ────────┘
   │
  You see the answer printed
```

---

## BEFORE YOU START — What You Need

| Requirement | Details |
|---|---|
| **AWS Account** | Free tier works. Sign up at [aws.amazon.com](https://aws.amazon.com) |
| **Python 3.10+** | Download from [python.org](https://python.org) |
| **A terminal** | Mac: Terminal app. Windows: Command Prompt or PowerShell |

**You do NOT need Docker.** The default deployment method (direct code deploy) handles everything without it.

---

## PART 1 — AWS Setup (One Time Only)

### Step 1.1 — Install the AWS CLI

The AWS CLI lets your computer communicate with AWS.

**Mac (using Homebrew):**
```bash
brew install awscli
```

**Mac (without Homebrew):**
```bash
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"
sudo installer -pkg AWSCLIV2.pkg -target /
```

**Windows:**
Download and run the installer from:
`https://awscli.amazonaws.com/AWSCLIV2.msi`

**Linux:**
```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```

✅ Verify it installed correctly:
```bash
aws --version
# Should print something like: aws-cli/2.x.x Python/3.x ...
```

---

### Step 1.2 — Get Your AWS Access Keys

1. Log in to the [AWS Console](https://console.aws.amazon.com)
2. Click your **account name** in the top-right corner
3. Click **Security credentials**
4. Scroll down to the **Access keys** section
5. Click **Create access key**
6. Select **Command Line Interface (CLI)** → click **Next** → click **Create**
7. ⚠️ **Copy both keys NOW** — the Secret Access Key is only shown once

Now tell your computer about these keys:
```bash
aws configure
```

Enter each value when asked:
```
AWS Access Key ID:     PASTE_YOUR_ACCESS_KEY_ID_HERE
AWS Secret Access Key: PASTE_YOUR_SECRET_ACCESS_KEY_HERE
Default region name:   us-east-1
Default output format: json
```

✅ Verify it worked:
```bash
aws sts get-caller-identity
```
You should see your AWS account ID and username printed in JSON format.

---

### Step 1.3 — Enable Claude in AWS Bedrock

> ⚠️ This is the most commonly forgotten step. Skip it and you'll get "Access Denied" errors.

1. Go to the [AWS Bedrock Console](https://console.aws.amazon.com/bedrock)
2. In the top-right, make sure you are in the **us-east-1 (N. Virginia)** region
   - Click the region name and switch if needed
3. In the left sidebar, click **Model access**
4. Click the **Modify model access** button (or "Request model access")
5. Find **Anthropic → Claude 3.5 Sonnet v2** and tick the checkbox
6. Scroll down and click **Save changes**
7. Wait 1–2 minutes — refresh until the status shows **✅ Access granted**

---

### Step 1.4 — Create an IAM Role for AgentCore

AgentCore needs an AWS IAM Role to run your agent's code securely on its infrastructure.

Run these commands **one by one** in your terminal:

**Create the role:**
```bash
aws iam create-role \
  --role-name AgentCoreExecutionRole \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Principal": {
          "Service": "bedrock-agentcore.amazonaws.com"
        },
        "Action": "sts:AssumeRole"
      }
    ]
  }'
```

**Attach Bedrock permissions:**
```bash
aws iam attach-role-policy \
  --role-name AgentCoreExecutionRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonBedrockFullAccess
```

**Attach CloudWatch permissions (for logs):**
```bash
aws iam attach-role-policy \
  --role-name AgentCoreExecutionRole \
  --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess
```

**Get the role ARN (save this — you'll need it in Step 4):**
```bash
aws iam get-role \
  --role-name AgentCoreExecutionRole \
  --query Role.Arn \
  --output text
```

The output will look like:
```
arn:aws:iam::123456789012:role/AgentCoreExecutionRole
```

📋 **Copy and save this ARN.** You'll paste it in Step 4.

---

## PART 2 — Set Up Your Project

### Step 2.1 — Create a folder and put the files in it

```bash
mkdir ai_assistant
cd ai_assistant
```

Copy these 4 files into the `ai_assistant` folder:
- `agent.py`
- `requirements.txt`
- `invoke.py`
- `README.md`

### Step 2.2 — Create a Python virtual environment

A virtual environment keeps this project's packages isolated from the rest of your system.

```bash
python -m venv .venv
```

**Activate it:**

Mac / Linux:
```bash
source .venv/bin/activate
```

Windows:
```cmd
.venv\Scripts\activate
```

You'll see `(.venv)` appear at the start of your terminal prompt — that means it's active. ✅

> **Important:** Every time you open a new terminal to work on this project, activate the virtual environment again before running any commands.

### Step 2.3 — Install all packages

```bash
pip install -r requirements.txt
```

This installs AutoGen, the AgentCore SDK, the DuckDuckGo search library, and boto3. It takes 1–2 minutes.

---

## PART 3 — Test Locally First

Always test locally before deploying — it's faster and free.

### Step 3.1 — Start the local server

```bash
python agent.py
```

You should see:
```
INFO  Starting local dev server on http://localhost:8080
INFO  Uvicorn running on http://0.0.0.0:8080
```

Leave this terminal window open.

### Step 3.2 — Open a second terminal and test

**Mac / Linux:**
```bash
# Test 1: Say hello
curl -X POST http://localhost:8080/invocations \
     -H "Content-Type: application/json" \
     -d '{"prompt": "hello"}'

# Test 2: Ask a general question
curl -X POST http://localhost:8080/invocations \
     -H "Content-Type: application/json" \
     -d '{"prompt": "What is Python?"}'

# Test 3: Force an internet search
curl -X POST http://localhost:8080/invocations \
     -H "Content-Type: application/json" \
     -d '{"prompt": "What is the latest news about AI today?"}'
```

**Windows PowerShell:**
```powershell
# Test 1: Say hello
Invoke-WebRequest -Uri "http://localhost:8080/invocations" `
  -Method POST -ContentType "application/json" `
  -Body '{"prompt": "hello"}'
```

**Expected responses:**
- Test 1: A warm greeting + "how can I help you?"
- Test 2: An explanation of Python
- Test 3: Recent AI news (fetched live from the internet)

### Step 3.3 — Stop the local server

Go back to the first terminal and press `Ctrl + C`.

---

## PART 4 — Deploy to AWS AgentCore

### Step 4.1 — Configure the deployment

Replace `YOUR_ROLE_ARN` with the role ARN from Step 1.4:

```bash
agentcore configure \
  --entrypoint agent.py \
  --execution-role YOUR_ROLE_ARN \
  --region us-east-1 \
  --disable-memory
```

Example with a real ARN:
```bash
agentcore configure \
  --entrypoint agent.py \
  --execution-role arn:aws:iam::123456789012:role/AgentCoreExecutionRole \
  --region us-east-1 \
  --disable-memory
```

When prompted, press **Enter** to accept defaults.

This creates a hidden file `.bedrock_agentcore.yaml` with your deployment config.

### Step 4.2 — Deploy to AWS

```bash
agentcore launch
```

What happens during deployment:
1. Your code gets packaged
2. Uploaded to an AWS S3 bucket (created automatically)
3. AgentCore Runtime is created and provisioned
4. Your agent goes live on AWS infrastructure

This takes **5–10 minutes** ☕. You'll see progress output.

When done, you'll see output like:
```
✅ Deployment complete!

Agent ARN  : arn:aws:bedrock-agentcore:us-east-1:123456789012:agent-runtime/abc123xyz
CloudWatch : https://console.aws.amazon.com/cloudwatch/...
```

📋 **Copy the Agent ARN — you need it in Part 5.**

### Step 4.3 — Check the deployment status

```bash
agentcore status
```

Wait until you see **ACTIVE**. If it says CREATING, wait a minute and try again.

---

## PART 5 — Chat With Your Deployed Agent

### Step 5.1 — Add your Agent ARN to invoke.py

Open `invoke.py` in any text editor (Notepad, VS Code, etc.).

Find line 28:
```python
AGENT_ARN = "PASTE_YOUR_AGENT_ARN_HERE"
```

Replace it with your actual ARN:
```python
AGENT_ARN = "arn:aws:bedrock-agentcore:us-east-1:123456789012:agent-runtime/abc123xyz"
```

Save the file.

### Step 5.2 — Start the interactive chat

```bash
python invoke.py
```

You'll see:
```
════════════════════════════════════════════════════════════
  🤖  AI Assistant — powered by AutoGen + Claude on Bedrock
  🌐  Hosted on AWS Bedrock AgentCore
════════════════════════════════════════════════════════════
  Type your message and press Enter.
  Type  exit  or  quit  to stop.

You:
```

**Try these:**
```
You: hello
You: What can you do?
You: What is machine learning?
You: What happened in the news today?
You: Who won the latest Champions League match?
You: exit
```

---

## PART 6 — Deep Dive: What Each File Does

### agent.py
This is the brain of the project. It contains:

| Component | What it does |
|---|---|
| `web_search()` | Python function that queries DuckDuckGo and returns top 5 results. AutoGen reads its docstring to know when to use it. |
| `_build_model_client()` | Creates an AutoGen model client that calls Claude 3.5 Sonnet via AWS Bedrock. Handles credentials automatically. |
| `_build_agent()` | Creates a Microsoft AutoGen `AssistantAgent` armed with Claude + the web search tool + a system prompt. |
| `@app.entrypoint invoke()` | The function AgentCore calls for every incoming request. Extracts the prompt, runs the agent, returns the answer. |
| `BedrockAgentCoreApp` | The wrapper from the AWS SDK that turns your Python function into an HTTP server compatible with AgentCore. |

### requirements.txt
Lists all Python packages. Key ones:

| Package | Why |
|---|---|
| `bedrock-agentcore` | AWS SDK — provides `BedrockAgentCoreApp` |
| `bedrock-agentcore-starter-toolkit` | Provides the `agentcore` CLI command |
| `autogen-agentchat` | Microsoft AutoGen — the `AssistantAgent` class |
| `autogen-ext[anthropic]` | AutoGen's Bedrock/Anthropic model client |
| `ddgs` | DuckDuckGo search (no API key needed) |
| `boto3` | AWS SDK for Python — used in invoke.py |

### invoke.py
A simple Python script that:
1. Takes input from you in a loop
2. Sends it to AgentCore as a JSON payload via boto3
3. Reads the streaming response back
4. Prints the agent's answer

### README.md
This file — the guide you're reading.

---

## PART 7 — Understanding AutoGen (the Framework)

Microsoft AutoGen is an open-source framework for building AI agents. In this project we use **AutoGen AgentChat v0.4** — the high-level API.

### The AssistantAgent

```
AssistantAgent
├── model_client  →  Which AI model to use (Claude 3.5 Sonnet via Bedrock)
├── tools         →  List of Python functions the agent can call (web_search)
├── system_message→  Instructions that define the agent's behaviour
└── reflect_on_tool_use=True
                  →  After using a tool, Claude reads the result
                     and writes a natural summary (not raw JSON)
```

### How the agent processes a question

```
User: "What's the latest news about SpaceX?"

Step 1: Claude reads the question
Step 2: Claude thinks "this needs current info"
Step 3: Claude calls web_search("SpaceX latest news")
Step 4: DuckDuckGo returns 5 results
Step 5: Claude reads the results
Step 6: Claude writes a clean, natural answer
Step 7: You see: "Here are the latest SpaceX updates..."
```

```
User: "What is photosynthesis?"

Step 1: Claude reads the question
Step 2: Claude thinks "I know this — no search needed"
Step 3: Claude writes a direct answer
Step 4: You see: "Photosynthesis is the process by which..."
```

---

## PART 8 — Troubleshooting

### ❌ "ModuleNotFoundError: No module named 'bedrock_agentcore'"
Your virtual environment isn't active or packages aren't installed.
```bash
source .venv/bin/activate   # Mac/Linux
# OR
.venv\Scripts\activate      # Windows

pip install -r requirements.txt
```

### ❌ "Unable to locate credentials"
AWS credentials aren't configured.
```bash
aws configure
# Enter your Access Key ID and Secret Access Key
```

### ❌ "Access Denied" when calling Claude
You haven't enabled the model in Bedrock.
- Go to [Bedrock Console](https://console.aws.amazon.com/bedrock)
- Make sure you're in **us-east-1**
- Go to **Model access** → enable **Claude 3.5 Sonnet v2**
- Wait 2 minutes for the status to show Access granted

### ❌ "on-demand throughput isn't supported for this model"
Change the model ID in `agent.py` (line ~95):
```python
# Change:
"us.anthropic.claude-3-5-sonnet-20241022-v2:0"
# To:
"anthropic.claude-3-5-sonnet-20241022-v2:0"
```

### ❌ "Port 8080 is already in use" (local test)
Something else is running on port 8080. Either stop that process or skip local testing and deploy directly.

### ❌ Agent status stuck on CREATING
Deployment can take up to 10 minutes. Keep running `agentcore status` every minute.

### ❌ "ResourceNotFoundException" in invoke.py
The Agent ARN in invoke.py is wrong or the agent isn't deployed.
- Double check the ARN in invoke.py
- Run `agentcore status` to verify the agent is ACTIVE

### ❌ invoke.py prints empty response
Check the logs:
```bash
agentcore logs
```
Or view them in [CloudWatch](https://console.aws.amazon.com/cloudwatch).

---

## PART 9 — Clean Up (Stop AWS Charges)

AgentCore Runtime has a cost when running. To delete it:

**Option 1 — CLI (recommended):**
```bash
agentcore status          # note the agent name
agentcore remove          # follow the prompts
```

**Option 2 — AWS Console:**
1. Go to [Bedrock Console](https://console.aws.amazon.com/bedrock)
2. Click **AgentCore** → **Runtime** in the left sidebar
3. Select your agent → **Delete**

---

## PART 10 — What to Explore Next

Once your agent is working, here are natural next steps:

| Feature | What it adds | How |
|---|---|---|
| **AgentCore Memory** | Agent remembers past conversations | Remove `--disable-memory` from configure command |
| **More tools** | Calculator, weather API, database lookup | Add more Python functions to `tools=[]` |
| **Streaming** | See the answer appear word by word | Change `invoke()` to `async def` + `yield` |
| **AgentCore Observability** | See what your agent does step by step in CloudWatch | Enable CloudWatch Transaction Search |
| **Custom model** | Use Claude 3 Opus, Haiku, or Sonnet 4 | Change `BEDROCK_MODEL_ID` in agent.py |

---

## Quick Reference Card

```bash
# ── First time setup ──────────────────────────────────
pip install -r requirements.txt

# ── Test locally ──────────────────────────────────────
python agent.py
# (in another terminal)
curl -X POST http://localhost:8080/invocations \
     -H "Content-Type: application/json" \
     -d '{"prompt": "hello"}'

# ── Deploy to AWS ─────────────────────────────────────
agentcore configure \
  --entrypoint agent.py \
  --execution-role YOUR_ROLE_ARN \
  --region us-east-1 \
  --disable-memory

agentcore launch           # wait 5–10 minutes

agentcore status           # check it's ACTIVE

# ── Chat with deployed agent ──────────────────────────
# (edit AGENT_ARN in invoke.py first)
python invoke.py

# ── View logs ─────────────────────────────────────────
agentcore logs

# ── Remove agent (stop charges) ───────────────────────
agentcore remove
```

---

*Built with: [Microsoft AutoGen](https://github.com/microsoft/autogen) · [AWS Bedrock AgentCore](https://aws.amazon.com/bedrock/agentcore/) · [Anthropic Claude](https://anthropic.com)*
